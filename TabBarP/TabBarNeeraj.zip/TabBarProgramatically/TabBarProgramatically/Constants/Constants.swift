//
//  Constants.swift
//  TabBarProgramatically
//
//  Created by bitcot on 16/06/22.
//

import Foundation
import UIKit

struct Constants{
    
    static let users = [User(name: "William", contactNo: "1000000000", email: "userObjects", profileImage: UIImage(named: "AvatarMen")!),
                        User(name: "Mike", contactNo: "2000000000", email: "userObjects", profileImage: UIImage(named: "AvatarMen")!),
                        User(name: "Morbius", contactNo: "3000000000", email: "userObjects", profileImage: UIImage(named: "AvatarMen")!),
                        User(name: "Alane", contactNo: "4000000000", email: "userObjects", profileImage: UIImage(named: "AvatarMen")!),
                        User(name: "Nike", contactNo: "5000000000", email: "userObjects", profileImage: UIImage(named: "AvatarMen")!),
                        User(name: "Odin", contactNo: "6000000000", email: "userObjects", profileImage: UIImage(named: "AvatarMen")!),
                        User(name: "Jhon", contactNo: "7000000000", email: "userObjects", profileImage: UIImage(named: "AvatarMen")!),
                        User(name: "Margi", contactNo: "8000000000", email: "userObjects", profileImage: UIImage(named: "AvatarWomen")!),
                        User(name: "Scarlet", contactNo: "9000000000", email: "userObjects", profileImage: UIImage(named: "AvatarWomen")!),
                        User(name: "Kylei", contactNo: "1000000000", email: "userObjects", profileImage: UIImage(named: "AvatarWomen")!),
                        User(name: "Paul", contactNo: "1100000000", email: "userObjects", profileImage: UIImage(named: "AvatarMen")!),
                        User(name: "Victory", contactNo: "1200000000", email: "userObjects", profileImage: UIImage(named: "AvatarWomen")!),
                        User(name: "Elizabeth", contactNo: "1300000000", email: "userObjects", profileImage: UIImage(named: "AvatarWomen")!),
                        User(name: "Paper", contactNo: "1400000000", email: "userObjects", profileImage: UIImage(named: "AvatarWomen")!),
                        User(name: "Nik", contactNo: "1500000000", email: "userObjects", profileImage: UIImage(named: "AvatarMen")!),
                        User(name: "Bhotom", contactNo: "1600000000", email: "userObjects", profileImage: UIImage(named: "AvatarMen")!),
                        User(name: "Dr. Beth", contactNo: "1700000000", email: "userObjects", profileImage: UIImage(named: "AvatarWomen")!),
                        User(name: "Vin Diesel", contactNo: "1800000000", email: "userObjects", profileImage: UIImage(named: "AvatarMen")!),
                        User(name: "Brian", contactNo: "1900000000", email: "userObjects", profileImage: UIImage(named: "AvatarMen")!),
                        User(name: "Jorge", contactNo: "2000000000", email: "userObjects", profileImage: UIImage(named: "AvatarMen")!),
                        User(name: "Reffary", contactNo: "2100000000", email: "userObjects", profileImage: UIImage(named: "AvatarMen")!),
                        User(name: "Ember", contactNo: "2200000000", email: "userObjects", profileImage: UIImage(named: "AvatarWomen")!),
                        User(name: "Olivia", contactNo: "2300000000", email: "userObjects", profileImage: UIImage(named: "AvatarWomen")!),
                        User(name: "Emma", contactNo: "2400000000", email: "userObjects", profileImage: UIImage(named: "AvatarWomen")!),
                        User(name: "Mia", contactNo: "2500000000", email: "userObjects", profileImage: UIImage(named: "AvatarWomen")!),
                        User(name: "Isabella", contactNo: "2600000000", email: "userObjects", profileImage: UIImage(named: "AvatarWomen")!),
                        User(name: "Amelia", contactNo: "2700000000", email: "userObjects", profileImage: UIImage(named: "AvatarWomen")!),
                        User(name: "Charlotte", contactNo: "2800000000", email: "userObjects", profileImage: UIImage(named: "AvatarWomen")!),
                        User(name: "Michael", contactNo: "2900000000", email: "userObjects", profileImage: UIImage(named: "AvatarMen")!),
                        User(name: "Robert", contactNo: "3000000000", email: "userObjects", profileImage: UIImage(named: "AvatarMen")!),
                        User(name: "Ethan", contactNo: "3100000000", email: "userObjects", profileImage: UIImage(named: "AvatarWomen")!),
                        User(name: "Daniel", contactNo: "3200000000", email: "userObjects", profileImage: UIImage(named: "AvatarMen")!),
                        User(name: "Noah", contactNo: "3300000000", email: "userObjects", profileImage: UIImage(named: "AvatarMen")!),
                        User(name: "Anthony", contactNo: "3400000000", email: "userObjects", profileImage: UIImage(named: "AvatarMen")!),
                        User(name: "Mason", contactNo: "3500000000", email: "userObjects", profileImage: UIImage(named: "AvatarMen")!) ]

    
}

struct sideMenuURL{
    static let bitCotURL:URL = URL(string: "https://www.bitcot.com/")!
    static let privacyURL:URL = URL(string: "https://www.bitcot.com/privacy/")!
    static let aboutURL:URL = URL(string: "https://www.bitcot.com/about-us/")!
}

struct SideMenuConstants{
    static let sideBar = [SideBarMenu(imgIcon: UIImage(named: "DesktopIcon")!, lblTitle: "Bit-Cot App Development Company", count: 1), SideBarMenu(imgIcon: UIImage(named: "PrivacyIcon")!, lblTitle: "Privacy", count: 2), SideBarMenu(imgIcon: UIImage(named: "AboutIcon")!, lblTitle: "About", count: 3), SideBarMenu(imgIcon: UIImage(named: "SignOutIcon")!, lblTitle: "Sign Out", count: 4)]
}
