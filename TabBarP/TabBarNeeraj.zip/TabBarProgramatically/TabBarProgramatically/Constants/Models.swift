//
//  Models.swift
//  TabBarProgramatically
//
//  Created by bitcot on 16/06/22.
//

import Foundation
import UIKit

struct User{
    var name : String
    var contactNo : String
    var email : String
    var profileImage : UIImage
    var isFavourite : Bool = false
    
    init(name:String, contactNo:String, email:String, profileImage:UIImage){
        self.name = name
        self.contactNo = contactNo
        self.email = email
        self.profileImage = profileImage
    }
}

struct SideBarMenu{
    var imgIcon:UIImage
    var lblTitle:String
    var count:Int
    
    init(imgIcon:UIImage, lblTitle:String, count:Int){
        self.imgIcon = imgIcon
        self.lblTitle = lblTitle
        self.count = count
    }
}

