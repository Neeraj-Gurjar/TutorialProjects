//
//  TabBar.swift
//  TabBarProgramatically
//
//  Created by bitcot on 15/06/22.
//

import UIKit

class TabBar: UITabBarController {
    

    override func viewDidLoad() {
        super.viewDidLoad()
        tabBar.unselectedItemTintColor = .white
        tabBar.selectedImageTintColor = .orange
        tabBar.isTranslucent = true
        tabBar.backgroundColor = .black
        tabBar.alpha = 0.9
           setupVCs()
        
    }
    
    func setupVCs() {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let classmateviewController = storyboard.instantiateViewController(withIdentifier: "ClassmatesViewController") as! ClassmatesViewController
        classmateviewController.tabBarItem = UITabBarItem(title: "ClassMates", image: UIImage(named: "Classmates"), tag: 0)
        let eventviewController = storyboard.instantiateViewController(withIdentifier: "EventsViewController") as! EventsViewController
        eventviewController.tabBarItem = UITabBarItem(title: "Events", image: UIImage(named: "Events"), tag: 0)
        let memoriesviewController = storyboard.instantiateViewController(withIdentifier: "MemoriesViewController") as! MemoriesViewController
        memoriesviewController.tabBarItem = UITabBarItem(title: "Memories", image: UIImage(named: "Memories"), tag: 0)
        let galleryviewController = storyboard.instantiateViewController(withIdentifier: "GalleryViewController") as! GalleryViewController
        galleryviewController.tabBarItem = UITabBarItem(title: "Gallery", image: UIImage(named: "Gallery"), tag: 0)
        let chatviewController = storyboard.instantiateViewController(withIdentifier: "ChatViewController") as! ChatViewController
        chatviewController.tabBarItem = UITabBarItem(title: "Chat", image: UIImage(named: "Chat"), tag: 0)
        viewControllers = [classmateviewController, eventviewController, memoriesviewController, galleryviewController, chatviewController]

       }


}
