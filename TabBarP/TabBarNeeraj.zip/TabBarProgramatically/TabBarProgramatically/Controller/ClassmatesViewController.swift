//
//  ClassmatesViewController.swift
//  TabBarProgramatically
//
//  Created by bitcot on 15/06/22.
//

import UIKit
import SideMenu

class ClassmatesViewController: UIViewController {
    
    // @IBOutlet weak var searchBar:UISearchBar!
    @IBOutlet weak var segmentedControl:UISegmentedControl!
    @IBOutlet weak var collectionVwClassmates:UICollectionView!
    @IBOutlet weak var lblNoFavorite:UILabel!
    
    var users = [User]()
    var filteredUsers: [User] = []
    var favoritedUsers:[User] = []
    
    let searchController = UISearchController(searchResultsController: nil)
    
    var isSearchBarEmpty: Bool {
        return searchController.searchBar.text?.isEmpty ?? true
    }
    
    var isFiltering: Bool {
        return searchController.isActive && !isSearchBarEmpty
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.users = Constants.users
        setUpCollectionView()
        searchController.searchResultsUpdater = self
        searchController.searchBar.placeholder = "Search"
        navigationItem.searchController = searchController
        
    }
    
    func setUpCollectionView(){
        collectionVwClassmates.dataSource = self
        collectionVwClassmates.delegate = self
        
        let nib = UINib(nibName: ClassmatesCollectionViewCell.identifier, bundle: nil)
        collectionVwClassmates.register(nib, forCellWithReuseIdentifier: ClassmatesCollectionViewCell.identifier)
    }
    
    func filterContentForSearchText(_ searchText: String, category: User? = nil) {
        filteredUsers = users.filter { user in
            return user.name.lowercased().contains(searchText.lowercased())
        }
        collectionVwClassmates.reloadData()
    }
    
    
    @IBAction func didChangeSegmentControl(_ sender: UISegmentedControl) {
        collectionVwClassmates.reloadData()
    }
    
    
}
extension ClassmatesViewController:UICollectionViewDataSource,UICollectionViewDelegate,UICollectionViewDelegateFlowLayout{
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        if segmentedControl.selectedSegmentIndex == 1 {
            
            if isFiltering {
                return filteredUsers.count
            }else{
                return favoritedUsers.filter({$0.isFavourite}).count
            }
        }else {
            if isFiltering {
                return filteredUsers.count
            }else{
                return users.count
            }
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionVwClassmates.dequeueReusableCell(withReuseIdentifier: ClassmatesCollectionViewCell.identifier, for: indexPath) as! ClassmatesCollectionViewCell
        cell.delegate = self
        var user : User!
        if segmentedControl.selectedSegmentIndex == 1 {
             user = isFiltering ? filteredUsers[indexPath.row] : favoritedUsers[indexPath.row]
        }else{
             user = isFiltering ? filteredUsers[indexPath.row] : users[indexPath.row]
        }
        cell.configureCell(user: user)

//        cell.configureCell(user: user, isFavourited: favoritedUsers.contains(where: {$0.contactNo == user.contactNo}))
        
      
//        favoritedUsers.forEach { User in
//            if User.contactNo == user.contactNo{
//                cell.configureCell(user: user, isFavourited: true)
//            }else{
//                cell.configureCell(user: user, isFavourited: false)
//            }
//        }
       
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        let size = (collectionVwClassmates.frame.size.width-30)/2
        return CGSize(width: size, height: 250)
    }
}

extension ClassmatesViewController: UISearchResultsUpdating {
    func updateSearchResults(for searchController: UISearchController) {
        let searchBar = searchController.searchBar
        filterContentForSearchText(searchBar.text!)
    }
}

extension ClassmatesViewController: ClassmatesCollectionViewCellDelegate{
    
    func didTapOnFavouriteButton(cell: ClassmatesCollectionViewCell) {
        if let indexpath = collectionVwClassmates.indexPath(for: cell){
            print(indexpath)
            if users[indexpath.row].isFavourite{
                users[indexpath.row].isFavourite = false
            }else{
                users[indexpath.row].isFavourite = true
            }
            favoritedUsers.removeAll()
            for u in users{
                if u.isFavourite{
                    print(u.isFavourite)
                    favoritedUsers.append(u)
                }
            }
            collectionVwClassmates.reloadData()
        }
    }
    
}
