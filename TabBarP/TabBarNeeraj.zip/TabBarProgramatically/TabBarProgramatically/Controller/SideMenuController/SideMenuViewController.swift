//
//  SideMenuViewController.swift
//  TabBarProgramatically
//
//  Created by bitcot on 17/06/22.
//

import UIKit

class SideMenuViewController: UIViewController {
    
    @IBOutlet weak var vwImageView:UIView!
    @IBOutlet weak var tblVwSideMenu:UITableView!
    
    var menuOptions = [SideBarMenu]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        menuOptions = SideMenuConstants.sideBar
        tblVwSetup()
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        vwImageView.layer.masksToBounds = true
        vwImageView.layer.cornerRadius = vwImageView.frame.height/2
    }
    
    func tblVwSetup(){
        tblVwSideMenu.dataSource = self
        tblVwSideMenu.delegate = self
        let uiNib = UINib(nibName: "SideMenuTableViewCell", bundle: nil)
        tblVwSideMenu.register(uiNib, forCellReuseIdentifier: SideMenuTableViewCell.identifier)
    }
}

extension SideMenuViewController:UITableViewDataSource,UITableViewDelegate{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return menuOptions.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tblVwSideMenu.dequeueReusableCell(withIdentifier: SideMenuTableViewCell.identifier, for: indexPath) as! SideMenuTableViewCell
        if menuOptions != nil{
            let menu = menuOptions[indexPath.row]
            cell.configureCell(menuOptions: menu)
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        return 55
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        var selectedMenu = menuOptions[indexPath.row].count
        let nextVc = self.storyboard?.instantiateViewController(withIdentifier: "WebViewController") as! WebViewController
        
        if selectedMenu == 1{
            nextVc.webURL = sideMenuURL.bitCotURL
            self.present(nextVc, animated: true, completion: nil)
        }else if selectedMenu == 2{
            nextVc.webURL = sideMenuURL.privacyURL
            self.present(nextVc, animated: true, completion: nil)
        }else if selectedMenu == 3{
            nextVc.webURL = sideMenuURL.aboutURL
            self.present(nextVc, animated: true, completion: nil)
        }else{
            ReUseFunc.showAlert(title: "LogOut", message: "Do you want to logout", controller: self)
        }
        
        
    }
    
}
