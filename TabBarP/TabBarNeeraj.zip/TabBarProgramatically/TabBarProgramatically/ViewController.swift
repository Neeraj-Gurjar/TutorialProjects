//
//  ViewController.swift
//  TabBarProgramatically
//
//  Created by bitcot on 15/06/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

