//
//  ReUseFunc.swift
//  TabBarProgramatically
//
//  Created by bitcot on 17/06/22.
//

import Foundation
import UIKit

struct ReUseFunc{
    
    static func showAlert(title:String, message:String, controller:UIViewController){
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let noAction = UIAlertAction(title: "No", style: .default, handler: nil)
        alert.addAction(noAction)
        let yesAction = UIAlertAction(title: "Yes", style: .destructive, handler: nil)
        alert.addAction(yesAction)
        controller.present(alert, animated: true, completion: nil)
    }
}
