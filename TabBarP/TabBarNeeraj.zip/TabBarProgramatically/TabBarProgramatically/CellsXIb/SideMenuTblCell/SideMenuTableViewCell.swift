//
//  SideMenuTableViewCell.swift
//  TabBarProgramatically
//
//  Created by bitcot on 17/06/22.
//

import UIKit

class SideMenuTableViewCell: UITableViewCell {
    
    @IBOutlet weak var imgIcon:UIImageView!
    @IBOutlet weak var lblTitle:UILabel!

    static let identifier = String(describing: SideMenuTableViewCell.self)

    override func awakeFromNib() {
        super.awakeFromNib()
        self.selectionStyle = .none
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func configureCell(menuOptions:SideBarMenu){
        imgIcon.image = menuOptions.imgIcon
        lblTitle.text = menuOptions.lblTitle
    }
    
}
