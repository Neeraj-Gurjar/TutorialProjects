////
////  SignUpViewController.swift
////  Task3
////
////  Created by bitcot on 11/06/22.
////
//
import UIKit


class SignUpViewController: UIViewController {
    
    // MARK:- Outlets
    @IBOutlet weak var tfFullName:UITextField!
    @IBOutlet weak var tfEmail:UITextField!
    @IBOutlet weak var tfMobileNumber:UITextField!
    @IBOutlet weak var tfDateOfBirth:UITextField!
    @IBOutlet weak var tfPassword:UITextField!
    @IBOutlet weak var imgPassEye:UIImageView!
    @IBOutlet weak var tfConfirmPassword:UITextField!
    @IBOutlet weak var imgConfirmPassEye:UIImageView!
    @IBOutlet weak var alreadyHaveAnAcc:UILabel!
    
    // Button outlet
    @IBOutlet weak var signUpBackgroundVw:UIView!
    @IBOutlet weak var btnSignUp:UIButton!
    
    //Declare var and let
    var iconClickPass = true
    var iconClickConfirm = true
    var tfArray:[UITextField] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupTextFields()
        signUpBackgroundVw.layer.masksToBounds = true
        signUpBackgroundVw.layer.cornerRadius = 20
        Utility.setUpColorInLabelText(textString: "Already have an account signIn!", colorOne: UIColor.systemGray, colorTwo: ColorCode.appThemeColor!, forTextOne: "Already have an account", forTextTwo: "signIn!", setForLbl: alreadyHaveAnAcc)
        tfColorNormal()
        self.hideKeyboardWhenTapAround()
    
    }
    
    //MARK:- IBActions
    @IBAction func btnASignIn(_ sender: UIButton) {
        let nextVc = self.storyboard?.instantiateViewController(withIdentifier: "SignInViewController") as! SignInViewController
        
        self.navigationController?.pushViewController(nextVc, animated: true)
        
    }
    
    @IBAction func openDatePicker(_ sender: UIButton){
        
        let nextVc = self.storyboard?.instantiateViewController(withIdentifier: "DateOfBirthViewController") as! DateOfBirthViewController
        nextVc.backController = self
        self.navigationController?.pushViewController(nextVc, animated: true)
        
    }
    
    @IBAction func btnAPassEye(_ sender: UIButton){
        
        Utility.securityEye(textF: tfPassword, iconImage: imgPassEye, iconClick: iconClickPass)
        iconClickPass = !iconClickPass
        
    }
    
    @IBAction func btnAConfirmPassEye(_ sender: UIButton){
        
        Utility.securityEye(textF: tfConfirmPassword, iconImage: imgConfirmPassEye, iconClick: iconClickConfirm)
        iconClickConfirm = !iconClickConfirm
        
    }
    
    @IBAction func btnASignUp(_ sender: UIButton){
        
        setupTextFields()
        signUpValidationCheck()
        
    }
    
    //MARK:- Function
    func setupTextFields(){
        
        tfArray = [tfFullName, tfEmail, tfMobileNumber, tfDateOfBirth, tfPassword, tfConfirmPassword]
        for i in tfArray{
            i.delegate = self
            i.layer.masksToBounds = true
            i.layer.borderWidth = 0.5
            i.layer.borderColor = UIColor.lightGray.cgColor
            i.layer.cornerRadius = 10
            i.textColor = ColorCode.appThemeColor
        }
        
    }
    
    //Validation
    
    @objc func signUpValidationCheck(){
        
        if tfFullName.text == ""{
            Utility.borderColor(tfName: tfFullName, colorName: ColorCode.appRed!)
            
            showAlert(title: "", message: MessageString.enterFullName)
        }else if tfEmail.text == ""{
            Utility.borderColor(tfName: tfEmail, colorName: ColorCode.appRed!)
            showAlert(title: "", message: MessageString.enterEmail)
        }else if tfMobileNumber.text == ""{
            Utility.borderColor(tfName: tfMobileNumber, colorName: ColorCode.appRed!)
            showAlert(title: "", message: MessageString.enterMobile)
        }else if tfDateOfBirth.text == ""{
            Utility.borderColor(tfName: tfDateOfBirth, colorName: ColorCode.appRed!)
            showAlert(title: "", message: MessageString.enterDateOfBirth)
        }else if tfPassword.text == ""{
            Utility.borderColor(tfName: tfPassword, colorName: ColorCode.appRed!)
            showAlert(title: "", message: MessageString.enterPassword)
        }else if tfConfirmPassword.text == ""{
            Utility.borderColor(tfName: tfConfirmPassword, colorName: ColorCode.appRed!)
            showAlert(title: "", message: MessageString.enterConfimPass)
        }else{
            if (tfEmail.text?.isValidEmail)!{
                if (tfMobileNumber.text?.isPhoneNumber)!{
                    if (tfPassword.text?.isPasswordValid)!{
                        if tfPassword.text != tfConfirmPassword.text{
                            Utility.borderColor(tfName: tfConfirmPassword, colorName: ColorCode.appRed!)
                            showAlert(title: "", message: MessageString.passMatch)
                        }else{
                            createUser()
                        }
                    }else{
                        Utility.borderColor(tfName: tfPassword, colorName: ColorCode.appRed!)
                        showAlert(title: "", message: MessageString.passWordCheck)
                    }
                }else{
                    Utility.borderColor(tfName: tfMobileNumber, colorName: ColorCode.appRed!)
                    showAlert(title: "", message: MessageString.numberCheck)
                }
            }else{
                Utility.borderColor(tfName: tfEmail, colorName: ColorCode.appRed!)
                showAlert(title: "", message: MessageString.emailCheck)
            }
        }
    }
    
    func createUser(){
        
        let userDef = UserDefaults.standard
        
        let user = User(name: tfFullName.text!, contactNo: tfMobileNumber.text!, email: tfEmail.text!, profileImage: "aaa", dateOfBirth: tfDateOfBirth.text!, address: "aa", passOut: "00/00" )
        
        let encoder = JSONEncoder()
        if let encoded = try? encoder.encode(user) {
            setUserDefault(key: UserDefaultKey.kUserkey, value: encoded as AnyObject)
            UserSession.sharedInstance.user = user
            setUserDefault(key: tfEmail.text!, value: tfPassword.text! as AnyObject)
            
            let nextVc = self.storyboard?.instantiateViewController(withIdentifier: "ClassmatesViewController") as! ClassmatesViewController
//            nextVc.user = user
            self.navigationController?.pushViewController(nextVc, animated: true)
            
        }
    }
    
}

extension SignUpViewController :UITextFieldDelegate{
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        switch textField {
        case tfFullName:
            Utility.borderColor(tfName: tfFullName, colorName: ColorCode.appThemeColor!)
            tfEmail.becomeFirstResponder()
        case tfEmail:
            if (tfEmail.text?.isValidEmail)!{
                Utility.borderColor(tfName: tfEmail, colorName: ColorCode.appThemeColor!)
                tfMobileNumber.becomeFirstResponder()
            }else{
                Utility.borderColor(tfName: tfEmail, colorName: ColorCode.appRed!)
                showAlert(title: "", message: MessageString.emailCheck)
            }
        case tfMobileNumber:
            if (tfMobileNumber.text?.isPhoneNumber)!{
                Utility.borderColor(tfName: tfMobileNumber, colorName: ColorCode.appThemeColor!)
                tfPassword.becomeFirstResponder()
            }else{
                Utility.borderColor(tfName: tfMobileNumber, colorName: ColorCode.appRed!)
                showAlert(title: "", message: MessageString.numberCheck)
            }
        case tfPassword:
            if (tfPassword.text?.isPasswordValid)!{
                Utility.borderColor(tfName: tfPassword, colorName: ColorCode.appThemeColor!)
                tfConfirmPassword.becomeFirstResponder()
            }else{
                Utility.borderColor(tfName: tfPassword, colorName: ColorCode.appRed!)
                showAlert(title: "", message: MessageString.passWordCheck)
            }
        default:
            if tfPassword.text != tfConfirmPassword.text{
                Utility.borderColor(tfName: tfConfirmPassword, colorName: ColorCode.appRed!)
                showAlert(title: "", message: MessageString.passMatch)
            }else{
                Utility.borderColor(tfName: tfConfirmPassword, colorName: ColorCode.appThemeColor!)
                tfConfirmPassword.resignFirstResponder()
            }
        }
        return true
    }
    
}

extension SignUpViewController{
    
    func tfColorNormal(){
        
        let tap = UITapGestureRecognizer(target:self, action: #selector(changeBorderColor))
        view.addGestureRecognizer(tap)
        
    }
    @objc func changeBorderColor(){
        
        for i in tfArray{
            i.layer.borderColor = UIColor.systemGray.cgColor
            i.textColor = ColorCode.appThemeColor
        }
        
    }
}
