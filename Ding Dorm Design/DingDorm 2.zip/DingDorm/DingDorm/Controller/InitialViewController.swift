//
//  InitialViewController.swift
//  DingDorm
//
//  Created by bitcot on 14/06/22.
//

import UIKit

class InitialViewController: UIViewController {
    
    @IBOutlet weak var lblDingDorm:UILabel!
    @IBOutlet weak var vwLoginBtn:UIView!
    @IBOutlet weak var vwSignUpBtn:UIView!
    @IBOutlet weak var btnLogIn:UIButton!
    @IBOutlet weak var btnSignUp:UIButton!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        setUpDingDormLabel()
        vwLoginBtn.layer.cornerRadius = 22
        vwSignUpBtn.layer.cornerRadius = 22
        
        btnLogIn.addTarget(self, action: #selector(goToLogInView), for: .touchUpInside)
        
   }
    
    func setUpDingDormLabel(){
        
        ReUseFunc.setUpColorInLabelText(textString: "Ding Dorm", colorOne: UIColor(named: "BasicHighGreen")!, colorTwo: UIColor(named: "BasicLightYellow")!, forTextOne: "Ding", forTextTwo: "Dorm", setForLbl: lblDingDorm)
        
    }
    
    @objc func goToLogInView(){
        
        let nextVc =  self.storyboard?.instantiateViewController(withIdentifier: ViewControllerIdentiFier.loginVC) as! LogInViewController
        
        self.navigationController?.pushViewController(nextVc, animated: true)
    
    }
    
}
