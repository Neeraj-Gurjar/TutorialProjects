//
//  InitialViewController.swift
//  DingDorm
//
//  Created by bitcot on 14/06/22.
//

import UIKit

class InitialViewController: UIViewController {
    
    @IBOutlet weak var lblDingDorm:UILabel!
    @IBOutlet weak var vwLoginBtn:UIView!
    @IBOutlet weak var vwSignUpBtn:UIView!
    @IBOutlet weak var btnLogIn:UIButton!
    @IBOutlet weak var btnSignUp:UIButton!
    

    var storedString = "Ding Dorm"
    override func viewDidLoad() {
        super.viewDidLoad()
        let attributedString:NSMutableAttributedString = NSMutableAttributedString(string: storedString)
        attributedString.setColor(color: UIColor(#colorLiteral(red: 0.003921568627, green: 0.1137254902, blue: 0.1333333333, alpha: 1)), forText: "Ding")
        attributedString.setColor(color: UIColor(#colorLiteral(red: 0.9725490196, green: 0.7450980392, blue: 0.2392156863, alpha: 1)), forText: "Dorm")
        lblDingDorm.attributedText = attributedString
        
        vwLoginBtn.layer.cornerRadius = 22
        vwSignUpBtn.layer.cornerRadius = 22
        
   }
}
