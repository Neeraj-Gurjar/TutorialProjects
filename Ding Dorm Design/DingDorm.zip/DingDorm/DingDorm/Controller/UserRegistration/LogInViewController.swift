//
//  LogInViewController.swift
//  DingDorm
//
//  Created by bitcot on 14/06/22.
//

import UIKit

class LogInViewController: UIViewController {

    @IBOutlet weak var tfEmail:UITextField!
    @IBOutlet weak var tfPassword:UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }

}
