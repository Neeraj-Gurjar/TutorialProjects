//
//  LoadingCollectionViewCell.swift
//  ReloadDataTavleView
//
//  Created by bitcot on 09/06/22.
//

import UIKit

class LoadingCollectionViewCell: UICollectionViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
