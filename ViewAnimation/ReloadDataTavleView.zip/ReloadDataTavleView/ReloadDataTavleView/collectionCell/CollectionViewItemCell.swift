//
//  CollectionViewItemCell.swift
//  ReloadDataTavleView
//
//  Created by bitcot on 09/06/22.
//

import UIKit

class CollectionViewItemCell: UICollectionViewCell {
    
    @IBOutlet weak var imageView:UIImageView!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
